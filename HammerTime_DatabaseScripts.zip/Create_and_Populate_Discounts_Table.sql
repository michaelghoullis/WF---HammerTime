USE [Hammers]
GO


/**** Drop the Discounts Table: ****/
/*
DROP TABLE [dbo].[Discounts]
GO
*/


/**** Create Discounts Table: ****/
/*
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Discounts](
	[DiscountID] [int] IDENTITY(1,1) NOT NULL,
	[DiscountAmount] [decimal](5, 2) NULL,
	[Description] [varchar](50) NULL,
 CONSTRAINT [PK_Discounts] PRIMARY KEY CLUSTERED 
(
	[DiscountID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

SET QUOTED_IDENTIFIER OFF
GO

SET ANSI_NULLS OFF
GO
*/


/**** Populate the Discounts Table: ****/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

SET IDENTITY_INSERT Discounts ON

INSERT INTO Discounts (DiscountID, Discount, Description) VALUES
(1, 5.00, 'Standard Discount'),
(2, 10.00, 'Repeat Customer Discount'),
(3, 20.00, 'Annual Sale Discount'),
(4, 40.00, 'Employee Discount')

SET IDENTITY_INSERT Discounts OFF




