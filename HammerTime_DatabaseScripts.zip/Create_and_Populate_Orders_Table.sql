USE [Hammers]
GO


/**** Drop the Orders Table: ****/
/*
DROP TABLE [dbo].[Orders]
GO
*/


/**** Create Orders Table: ****/
/*
SET ANSI_PADDING ON
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Orders](
	[OrderID] [int] IDENTITY(1,1) NOT NULL,
	[CustomerID] [int] NULL,
	[HammerID] [int] NULL,
	[Quantity] [int] NULL,
 CONSTRAINT [PK_Orders] PRIMARY KEY CLUSTERED 
(
	[OrderID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Orders]  WITH CHECK ADD  CONSTRAINT [FK_Orders_Customer] FOREIGN KEY([CustomerID])
REFERENCES [dbo].[Customers] ([CustomerID])
GO

ALTER TABLE [dbo].[Orders] CHECK CONSTRAINT [FK_Orders_Customer]
GO

ALTER TABLE [dbo].[Orders]  WITH CHECK ADD  CONSTRAINT [FK_Orders_Hammers] FOREIGN KEY([HammerID])
REFERENCES [dbo].[Hammers] ([HammerID])
GO

ALTER TABLE [dbo].[Orders] CHECK CONSTRAINT [FK_Orders_Hammers]
GO

SET ANSI_PADDING OFF
GO

SET ANSI_NULLS OFF
GO
*/


/**** Populate Orders Table: ****/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

SET IDENTITY_INSERT Orders ON

INSERT INTO Orders (OrderID, CustomerID, HammerID, Quantity) VALUES
(1, 4, 5, 2),
(2, 1, 2, 1),
(3, 5, 4, 1),
(4, 1, 4, 1),
(5, 3, 5, 10),
(6, 2, 1, 3),
(7, 2, 3, 1)


SET IDENTITY_INSERT Orders OFF




