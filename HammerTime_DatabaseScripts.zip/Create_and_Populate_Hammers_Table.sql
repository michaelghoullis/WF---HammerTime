USE [Hammers]
GO


/**** Drop the Hammers Table: ****/
/*
DROP TABLE [dbo].[Hammers]
GO
*/


/**** Create the Hammers Table: ****/
/*
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Hammers](
	[HammerID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](20) NULL,
	[Description] [varchar](50) NULL,
	[Price] [decimal](5, 2) NULL,
 CONSTRAINT [PK_Hammers] PRIMARY KEY CLUSTERED 
(
	[HammerID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_NULLS OFF
GO

SET ANSI_PADDING OFF
GO
*/


/**** Populate the Hammers Table: ****/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

SET IDENTITY_INSERT Hammers ON

INSERT INTO Hammers (HammerID, Name, Description, Price) VALUES
(1, 'Big Banger', '3-lb Roofing', 49.95),
(2, 'Homer', 'General Home Use', 9.95),
(3, 'The Pro I', 'Commercial Use', 15.20),
(4, 'The Pro II', 'Framing Hammer', 23.45),
(5, 'The Pro III', 'Framing Hammer Fiberglass', 24.80)

SET IDENTITY_INSERT Hammers OFF

