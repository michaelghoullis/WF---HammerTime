USE [Hammers]
GO


/**** Drop the Customers Table ****/
/*
DROP TABLE [dbo].[Customers]
GO
*/


/**** Create the Customers Table: ****/
/*
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Customers](
	[CustomerID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](50) NULL,
	[StateID] [int] NULL,
	[DiscountID] [int] NULL,
 CONSTRAINT [PK_Customers] PRIMARY KEY CLUSTERED 
(
	[CustomerID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Customers]  WITH CHECK ADD  CONSTRAINT [FK_Customers_Discounts] FOREIGN KEY([DiscountID])
REFERENCES [dbo].[Discounts] ([DiscountID])
GO

ALTER TABLE [dbo].[Customers] CHECK CONSTRAINT [FK_Customers_Discounts]
GO

ALTER TABLE [dbo].[Customers]  WITH CHECK ADD  CONSTRAINT [FK_Customers_States] FOREIGN KEY([StateID])
REFERENCES [dbo].[States] ([StateID])
GO

ALTER TABLE [dbo].[Customers] CHECK CONSTRAINT [FK_Customers_States]
GO
*/


/**** Populate the Customers Table: ****/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

SET IDENTITY_INSERT Customers ON

INSERT INTO Customers (CustomerID, Name, StateID, DiscountID) VALUES
(1, 'Jennifer Williams', 1, 2),
(2, 'Michael Houllis', 11, 4),
(3, 'Stephen Weintraub', 4, null),
(4, 'Marvin Sanchez', 22, 1),
(5, 'Sara James', 7, 3)

SET IDENTITY_INSERT Customers OFF

