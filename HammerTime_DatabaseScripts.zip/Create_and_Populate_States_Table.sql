USE [Hammers]
GO


/**** Drop the States Table: ****/
/*
DROP TABLE [dbo].[States]
GO
*/


/**** Create the States Table: ****/
/*
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[States](
	[StateID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](30) NULL,
	[Abbreviation] [varchar](2) NULL,
 CONSTRAINT [PK_States] PRIMARY KEY CLUSTERED 
(
	[StateID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_NULLS OFF
GO

SET ANSI_PADDING OFF
GO
*/


/**** Populate the States Table: ****/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

SET IDENTITY_INSERT States ON

INSERT INTO States (StateID, Name, Abbreviation) VALUES
(1, 'Alaska', 'AK'),
(2, 'Alabama', 'AL'),
(3, 'American Samoa', 'AS'),
(4, 'Arizona', 'AZ'),
(5, 'Arkansas', 'AR'),
(6, 'California', 'CA'),
(7, 'Colorado', 'CO'),
(8, 'Connecticut', 'CT'),
(9, 'Delaware', 'DE'),
(10, 'District of Columbia', 'DC'),
(11, 'Florida', 'FL'),
(12, 'Georgia', 'GA'), 
(13, 'Guam', 'GU'),
(14, 'Hawaii', 'HI'),
(15, 'Idaho', 'ID'),
(16, 'Illinois', 'IL'),
(17, 'Indiana', 'IN'),
(18, 'Iowa', 'IA'),
(19, 'Kansas', 'KS'),
(20, 'Kentucky', 'KY'),
(21, 'Louisiana', 'LA'),
(22, 'Maine', 'ME'),
(23, 'Maryland', 'MD'),
(24, 'Massachusetts', 'MA'),
(25, 'Michigan', 'MI'),
(26, 'Minnesota', 'MN'),
(27, 'Mississippi', 'MS'),
(28, 'Missouri', 'MO'),
(29, 'Montana', 'MT'),
(30, 'Nebraska', 'NE'),
(31, 'Nevada', 'NV'),
(32, 'New Hampshire', 'NH'),
(33, 'New Jersey', 'NJ'),
(34, 'New Mexico', 'NM'), 
(35, 'New York', 'NY'),
(36, 'North Carolina', 'NC'),
(37, 'North Dakota', 'ND'),
(38, 'Northern Mariana Islands', 'MP'),
(39, 'Ohio', 'OH'),
(40, 'Oklahoma', 'OK'),
(41, 'Oregon', 'OR'),
(42, 'Palau', 'PW'), 
(43, 'Pennsylvania', 'PA'),
(44, 'Puerto Rico', 'PR'),
(45, 'Rhode Island', 'RI'),
(46, 'South Carolina', 'SC'),
(47, 'South Dakota', 'SD'),
(48, 'Tennessee', 'TN'),
(49, 'Texas', 'TX'), 
(50, 'Utah', 'UT'),
(51, 'Vermont', 'VT'),
(52, 'Virgin Islands', 'VI'),
(53, 'Virginia', 'VA'),
(54, 'Washington', 'WA'),
(55, 'West Virginia', 'WV'),
(56, 'Wisconsin', 'WI'), 
(57, 'Wyoming', 'WY'),
(58, 'Alberta', 'AB'),
(59, 'British Columbia', 'BC'),
(60, 'Manitoba', 'MB'),
(61, 'New Brunswick', 'NB'),
(62, 'Newfoundland and Labrador', 'NL'),
(63, 'Northwest Territories', 'NT'),
(64, 'Nova Scotia', 'NS'),
(65, 'Nunavut', 'NU'),
(66, 'Ontario', 'ON'),
(67, 'Prince Edward Island', 'PE'),
(68, 'Qu�bec', 'QC'),
(69, 'Saskatchewan', 'SK'),
(70, 'Yukon Territory', 'YT'); 

SET IDENTITY_INSERT States OFF

