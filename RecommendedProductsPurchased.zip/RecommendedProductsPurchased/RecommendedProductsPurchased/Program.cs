﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecommendedProductsPurchased {
	class Program {
		static void Main(string[] args)
		{
			//wait for user input:
			Console.WriteLine("Press Enter to do RecommendedProductsPurchased()");
			Console.ReadLine();

			//generate the two overlapping Product lists to compare:
			Product p = new Product();
			var cartList = p.getProductList(1, 7);
			var recommendedList = p.getProductList(3, 14);

			//get the list of purchased Products:
			var purchasedList = p.RecommendedProductsPurchased(cartList, recommendedList);

			//display the list of purchased Products:
			Console.WriteLine("Products Actually Purchased:");
			Console.WriteLine();
			foreach(Product prod in purchasedList)
			{
				Console.WriteLine("Name: " + prod.Name);
				Console.WriteLine("ProductID: " + prod.ProductID);
				Console.WriteLine("Quantity: " + prod.Quantity);
				Console.WriteLine();
				Console.WriteLine("-------------------------------------");
				Console.WriteLine();
			}
			Console.ReadLine();
		}
	}

	public class Product
	{
		public string Name;
		public int ProductID;
		public decimal Cost;
		public int Quantity;

		//Generate sample Product lists:
		public List<Product> getProductList(int startID, int endID)
		{
			var name="Prod";
			decimal cost = 14.00M;
			var productList = new List<Product>();
			Product p;

			for(int i=startID;i<endID;i++)
			{
				p = new Product();
				p.Name = name + i;
				p.ProductID = i;
				p.Cost = cost + i;
				p.Quantity = i;
				productList.Add(p);
			}
			return productList;
		}

		//return a list of Products that were actually purchased:
		public IList<Product> RecommendedProductsPurchased(IList<Product> cartList, IList<Product> recommendedList)
		{
			var derivedProductsList =
				from recommendedItems in recommendedList
				join cartItems in cartList on recommendedItems.ProductID equals cartItems.ProductID 
				select recommendedItems;

			var purchasedProductsList = derivedProductsList.ToList<Product>();
			return purchasedProductsList;
		}

	}
}






